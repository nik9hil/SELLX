This folder contains original sample templates; not to be used in the project directly.
