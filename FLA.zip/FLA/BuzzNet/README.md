# Requirements
1. Flask
2. SQLAlchemy
3. Flak-user
4. WT-Forms

# To-do:
1. <strike> Create template</strike>
2. <strike> App route</strike>
3. Create a Form
4. Create a DB
5. Keep a user session
